from tensorflow.keras.models import Model
from tensorflow.keras.losses import MSE, KLD
from tensorflow.keras.layers import Dense, Dropout, Input, Lambda
from spektral.layers import GraphAttention, GraphConvSkip, TAGConv
from Graph_autoencoder_loss import dist_loss
from tensorflow.keras.initializers import GlorotUniform
from Graph_autoencoder_layers import *
import tensorflow_probability as tfp
import numpy as np


class Graph_network(tf.keras.Model):

    def __init__(self, X, adj, adj_n, hidden_dim=128, latent_dim=10, dec_dim=None, adj_dim=32,
                 decA="DBL", layer_enc = "GAT"):
        super(Graph_network, self).__init__()
        if dec_dim is None:
            dec_dim = [64, 256, 512]
        self.latent_dim = latent_dim
        self.X = X
        self.adj = np.float32(adj)
        self.adj_n = np.float32(adj_n)
        self.n_sample = X.shape[0]
        self.in_dim = X.shape[1]
        self.sparse = False

        initializer = GlorotUniform(seed=7)

        # Encoder
        X_input = Input(shape=self.in_dim)
        h = Dropout(0.2)(X_input)
        if layer_enc == "GAT":
            A_in = Input(shape=self.n_sample)
            h = GraphAttention(channels=hidden_dim, attn_heads=1, kernel_initializer=initializer, activation="relu")([h, A_in])
            z_mean = GraphAttention(channels=latent_dim, kernel_initializer=initializer, attn_heads=1)([h, A_in])
        elif layer_enc == "GCN":
            A_in = Input(shape=self.n_sample)
            h = GraphConvSkip(channels=hidden_dim,  kernel_initializer=initializer, activation="relu")([h, A_in])
            z_mean = GraphConvSkip(channels=latent_dim, kernel_initializer=initializer)([h, A_in])

        self.encoder = Model(inputs=[X_input, A_in], outputs=z_mean, name="encoder")
        clustering_layer = ClusteringLayer(name='clustering')(z_mean)
        self.cluster_model = Model(inputs=[X_input, A_in], outputs=clustering_layer, name="cluster_encoder")

        # Adjacency matrix decoder
        if decA == "DBL":
            dec_in = Input(shape=latent_dim)
            h = Dense(units=adj_dim, activation=None)(dec_in)
            h = Bilinear()(h)
            dec_out = Lambda(lambda z: tf.nn.sigmoid(z))(h)
            self.decoderA = Model(inputs=dec_in, outputs=dec_out, name="decoder1")
        elif decA == "BL":
            dec_in = Input(shape=latent_dim)
            h = Bilinear()(dec_in)
            dec_out = Lambda(lambda z: tf.nn.sigmoid(z))(h)
            self.decoderA = Model(inputs=dec_in, outputs=dec_out, name="decoder1")
        elif decA == "IP":
            dec_in = Input(shape=latent_dim)
            dec_out = Lambda(lambda z: tf.nn.sigmoid(tf.matmul(z, tf.transpose(z))))(dec_in)
            self.decoderA = Model(inputs=dec_in, outputs=dec_out, name="decoder1")
        else:
            self.decoderA = None

        # Expression matrix decoder

        decx_in = Input(shape=latent_dim)
        h = Dense(units=dec_dim[0], activation="relu")(decx_in)
        h = Dense(units=dec_dim[1], activation="relu")(h)
        h = Dense(units=dec_dim[2], activation="relu")(h)
        decx_out = Dense(units=self.in_dim)(h)
        self.decoderX = Model(inputs=decx_in, outputs=decx_out, name="decoderX")


    def train(self, epochs=80, info_step=10, lr=2e-3, W_a=0.3, W_x=1,
                  W_d=0, min_dist=0.5, max_dist=20):

        optimizer = tf.keras.optimizers.Adam(learning_rate=lr)
        if self.sparse == True:
            self.adj_n = tfp.math.dense_to_sparse(self.adj_n)

        # Training
        for epoch in range(1, epochs + 1):
            with tf.GradientTape(persistent=True) as tape:
                z = self.encoder([self.X, self.adj_n])
                X_out = self.decoderX(z)
                A_out = self.decoderA(z)
                if W_d:
                    Dist_loss = tf.reduce_mean(dist_loss(z, min_dist, max_dist = max_dist))
                A_rec_loss = tf.reduce_mean(MSE(self.adj, A_out))
                X_rec_loss = tf.reduce_mean(MSE(self.X, X_out))
                loss = W_a * A_rec_loss + W_x * X_rec_loss
                if W_d:
                    loss += W_d * Dist_loss

            vars = self.trainable_weights
            grads = tape.gradient(loss, vars)
            optimizer.apply_gradients(zip(grads, vars))
            if epoch % info_step == 0:
                if W_d:
                    print("Epoch", epoch, " X_rec_loss:", X_rec_loss, "  A_rec_loss:", A_rec_loss,
                      "Dist_loss:", Dist_loss)
                else:
                    print("Epoch", epoch, " X_rec_loss:", X_rec_loss, "  A_rec_loss:", A_rec_loss)



        print("Pre_train Finish!")


    def embedding(self, count, adj_n):
        if self.sparse:
            adj_n = tfp.math.dense_to_sparse(adj_n)
        return np.array(self.encoder([count, adj_n]))

    def rec_A(self, count, adj_n):
        h = self.encoder([count, adj_n])
        rec_A = self.decoderA(h)
        return np.array(rec_A)
from DAE import DAE
import numpy as np
import tensorflow as tf
from tensorflow.python.framework.ops import disable_eager_execution
disable_eager_execution()
from keras.models import Model
from keras.optimizers import SGD, Adam
import scanpy as sc
import h5py
from preprocess import read_dataset, normalize


# load dataset
optimizer1 = Adam(amsgrad=True)
optimizer2 = 'adadelta'

data_mat = h5py.File('Zeisel.h5')
x = np.array(data_mat['X'])
y = np.array(data_mat['Y'])

# preprocessing scRNA-seq read counts matrix
adata = sc.AnnData(x)
adata.obs['Group'] = y

adata = read_dataset(adata,
                transpose=False,
                test_split=False,
                copy=True)

adata = normalize(adata,
                size_factors=True,
                normalize_input=True,
                logtrans_input=True)

input_size = adata.n_vars

print(adata.X.shape)
print(y.shape)

x_sd = adata.X.std(0)
x_sd_median = np.median(x_sd)
print("median of gene sd: %.5f" % x_sd_median)


# Define DAE model
DAE = DAE(dims=[input_size, 512, 256, 128], noise_sd=2.5)
print("autocoder summary")
DAE.autoencoder.summary()
print("model summary")
DAE.model.summary()


# train DAE to obtain low dimensional represent of raw data
DAE.train(x=[adata.X, adata.obs.size_factors],
             y=adata.raw.X,
             batch_size=256,
             epochs=100,
             optimizer=optimizer1)


hidden_layer = DAE.model.get_layer(name='encoder_hidden').get_output_at(1)
hidden_output_model = Model(inputs = DAE.model.input, outputs = hidden_layer)
hidden_output = hidden_output_model.predict([adata.X, adata.obs.size_factors])
count = np.asarray(hidden_output)        # obtain low dimensional represent
np.save('Zeisel.npy', count)

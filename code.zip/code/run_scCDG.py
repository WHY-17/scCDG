import  tensorflow as tf
from sklearn.cluster import KMeans
from sklearn import metrics
import numpy as np
import h5py
import scanpy as sc
#Remove warnings
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
from Graph_autoencoder import Graph_network
from Graph_autoencoder_preprocess import get_adj



# The low dimensional representation of DAE is used as the input of Graph_model
# Build model
count = np.load('10X_PBMC_100.npy')        # The output of DAE
f = h5py.File('10X_PBMC.h5')
y = np.array(f['Y']).reshape(-1,)

adj, adj_n = get_adj(count)
model = Graph_network(count, adj=adj, adj_n=adj_n, layer_enc='GCN', decA='IP')

# Training Graph_network
model.train(epochs=200)
Y = model.embedding(count, adj_n)

kmeans = KMeans()
y_pred = kmeans.fit_predict(Y)
nmi = np.round(metrics.normalized_mutual_info_score(y, y_pred), 5)
ari = np.round(metrics.adjusted_rand_score(y, y_pred), 5)
sil = metrics.silhouette_score(Y, y_pred)
print('NMI:', nmi)
print('ARI:', ari)
print('SIL:', sil)

adata = sc.AnnData(Y)
adata.obs['Group'] = y_pred
sc.pp.neighbors(adata, n_neighbors=50)
sc.tl.umap(adata, n_components=2)
sc.pl.umap(adata, color='Group')